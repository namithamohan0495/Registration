<?php
    error_reporting(1);
    $firstname_err="";
    $lastname_err="";
    $designation_err = "";
    $mobile_number_err="";
    $dob_err = "";
    $email_err = "";
    $password_err = "";
    $repassword_err = "";
    include 'registration_action.php';

  ?>
    <!Doctype html>
    <html>
    <head>
	<title>Registration</title>
	<link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script type="text/javascript" src="js/validation.js"></script>
    <script>
        $( function() {
        $( "#dob" ).datepicker();
        } );
  </script>
    </head>
    <body>
    <div class="container">
    
    <h2>Enter your details </h2>
	<form action="" method="post" id ="myForm" name="myform" enctype="multipart/form-data">
	    <div class="form_fill">
	    <table>
	    
	    <tr>
	      <td>
	      <h3>Personal details</h3>
	      </td>
	      <td></td>
	    </tr>
	  
	    <tr>
            <td>First name:<b>*</b></td>
            <td><input type="text" name="first_name" id="first_name" value="<?php echo $first_name?>"></td>
            <td><div class="error"><?php echo $firstname_err;?></div></td>
            <td><label id="1"></label></td>
	    </tr>
	    <tr>
            <td>Last name:<b>*</b></td>
            <td><input type="text" name="last_name" id="last_name" value="<?php echo $last_name?>"></td>
            <td><div class="error"><?php echo $lastname_err;?></div></td>
            <td><label id="2"></label></td>
	    </tr>
        <tr>
            <td>Designation:<b>*</b></td>
            <td><input type="text" name="designation" id="designation" value="<?php echo $designation?>"></td>
            <td><div class="error"><?php echo $designation_err;?></div></td>
            <td><label id="3"></label></td>
	    </tr>
        <tr>
            <td>Date of Birth:<b>*</b></td>
            <td><input type="text" name="dob" id="dob" value="<?php echo $dob?>"></td>
            <td><div class="error"><?php echo $dob_err;?></div></td>
            <td><label id="4"></label></td>
	    </tr>
        <tr>
            <td>Enter e-mail id: <b>*</b></td>
            <td><input type="text" name="email" id="email" value="<?php echo $email?>" ></td>
            <td><div class="error"><?php echo $email_err;?></div></td>
            <td><label id="5"></label></td>
	    </tr>
        <tr>
		<td>Mobile number:<b>*</b></td>

            <td><input type="text" name="mobile_number" id="mobile_number" value="<?php echo $mobile_number?>"></td>
            <td><div class="error"><?php echo $mobile_number_err;?></div></td>
            <td><label id="6"></label></td>
	    </tr>
        <tr>
            <td>Enter password:<b>*</b></td><td><input type="password" name="password" id="password" value="<?php echo $password?>"></td> 
            <td><div class="error"><?php echo $password_err;?></div></td>
            <td><label id="7"></label></td>
        </tr>

        <tr>
        <td>Re-enter password:<b>*</b></td>
            <td><input type="password" name="repassword" id="repassword" value="<?php echo $repassword?>"></td>
            <td><div class="error"><?php echo $repassword_err;?></div></td>
            <td><label id="8"></label></td>
	    <tr>
	    <td colspan="2">
	    </table>
	  
	    
	<br><br>
	    <table>
		    <tr>
		  <td></td>
		  <td></td>
		  <td>		   
			Upload Profile Image:
			<input type="file" name="fileToUpload" id="fileToUpload">
			<br><br>
			  <div class="button_1">
	    <button type="submit" name="submit" value="Submit" id="submit">Submit</button>
	    </div>			
		  </td>
		  </tr>	  
		  <tr>
			<td></td>
			<td></td>
			<td><div class="error">
			    <?php 
			      echo $type_err;	
			      echo $uploaded_file;
			      echo $uploaded_file_err;
			    ?>
			</div></td>
		  </tr>
	    
	    </table>
	    </div>
	</form>
      </div>
    </body>
    </html>
    