$(document).ready(function () {
  $("#submit").click(function () {
    var first_name = $("#first_name").val();
    var last_name = $("#last_name").val();
    var designation = $("#designation").val();
    var mobile_number = $("#mobile_number").val();
    var email = $("#email").val();
    var password = $("#password").val();
    var repassword = $("#repassword").val();
    var flag = 0;
    //code for validation
    if (first_name == "") {
      $("#1").text("*First name required").css("color", "red");
      flag = 1;
    } else if (!/^[a-zA-Z\s]{3,16}$/.test(first_name)) {
      $("#1").text("Enter valid first name").css("color", "red");
      flag = 1;
    } else {
      $("#1").text("");
    }
    if (last_name == "") {
      $("#2").text("*Last name required").css("color", "red");
      flag = 1;
    } else if (!/^[a-zA-Z\s]{1,16}$/.test(last_name)) {
      $("#2").text("Enter valid last name").css("color", "red");
      flag = 1;
    } else {
      $("#2").text("");
    }
    if (designation == "") {
      $("#3").text("*Designation required").css("color", "red");
      flag = 1;
    } else if (!/^[a-zA-Z\s]{1,16}$/.test(last_name)) {
      $("#3").text("Enter valid designation").css("color", "red");
      flag = 1;
    } else {
      $("#3").text("");
    }
    if (mobile_number == "") {
      $("#6").text("*Mobile number required").css("color", "red");
      flag = 1;
    } else if (!/^(7||8||9)[0-9]{9}$/.test(mobile_number)) {
      $("#6").text("Invalid mobile number").css("color", "red");
      flag = 1;
    } else {
      $("#6").text("");
    }
    if (email == "") {
      $("#5").text("*E-mail id required").css("color", "red");
      flag = 1;
    } else if (!/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/.test(email)) {
      $("#5").text("* Invalid e-mail id").css("color", "red");
      flag = 1;
    } else {
      $("#5").text("");
    }
    if (password == "") {
      $("#7").text("*password required").css("color", "red");
      flag = 1;
    } else if (
      !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,30}$/.test(
        password
      )
    ) {
      $("#7").text("*Invalid password").css("color", "red");
      flag = 1;
    } else {
      $("#7").text("");
    }
    if (repassword == "") {
      $("#8").text("*Re-enter password").css("color", "red");
      flag = 1;
    } else if (repassword != password) {
      $("#8").text("*Re-enter password").css("color", "red");
      flag = 1;
    } else {
      $("#8").text("");
    }
    if (flag == 0) {
      document.myform.submit();
    } else {
      return false;
    }
  });
});
