<?php
$servername = "localhost";
$username = "root";
$password = "redhat";
$dbname = "registration";
// Create connection
$mysqli = mysqli_connect($servername, $username, $password) or die("Connection error");
// Check connection

?> 