<?php
include 'dbconnection.php';
if (isset($_POST['submit'])) 
    {
	if (trim($_POST["first_name"])=="")  
	      {
		  $firstname_err="First name is required";
		  $flag=0;    
	      }
	  else if(!preg_match('/^[a-zA-Z\s]{3,16}$/',trim($_POST["first_name"])))
	      {
		  $firstname_err="Invalid first name";
		  $err['firstname_err'] = "Invalid first name";
		  $flag=0; 
	      }
	  else
	      {
		  $first_name=trim($_POST['first_name']);
		  $flag=1;
	      }
	  if (trim($_POST["last_name"])=="")  
	      {
		  $lastname_err="Last name is required";
		  $flag=0;    
	      }
	  else if(!preg_match('/^[a-zA-Z\s]{1,16}$/',trim($_POST["last_name"])))
	      {
		  $lastname_err="Invalid last name";
		  $flag=0; 
	      }
	  else
	      {
		  $last_name=trim($_POST['last_name']);
		  $flag=1;
          }
          if (trim($_POST["designation"])=="")  
	      {
		  $designation_err="Designation is required";
		  $flag=0;    
	      }
	  else if(!preg_match('/^[a-zA-Z\s]{1,16}$/',trim($_POST["designation"])))
	      {
		  $designation_err="Invalid designation";
		  $flag=0; 
	      }
	  else
	      {
		  $designation=trim($_POST['designation']);
		  $flag=1;
	      }
	  if (trim($_POST["mobile_number"])=="")
	      {
		  $mobile_number_err="Mobile number is required";
		  $flag=0; 
	      }
	  else if(!preg_match('/^(7||8||9)[0-9]{9}$/',trim($_POST['mobile_number'])))
	      {
		  $mobile_number_err="Invalid mobile number";
		  $flag=0;
	      }
	  else
	      {
		  $mobile_number=trim($_POST['mobile_number']);
		  $flag=1;
          }
          if (trim($_POST["email"])=="") 
	      {
		  $email_err="Email is required";
		  $flag=0;    
	      }
	  else if (!preg_match('/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/',trim($_POST['email'])))
	      {
		  $email_err="Invalid email";
		  $flag=0;
	      }  
	  else
	      {
		  $email=trim($_POST['email']);
		  $flag=1; 
	      }
	  if (trim($_POST["password"])=="")
	      {
		  $password_err="Password is required";
		  $flag=0;    
	      }
	  else if(!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,30}$/',trim($_POST['password'])))
	      {
		  $password_err="Invalid Password";
		  $flag=0; 
	      }
	  else
	      {
		  $password=trim($_POST['password']);
		  $flag=1; 
	      }
	  if (trim($_POST["repassword"])=="")
	      {
		  $repassword_err="Re-enter password";
		  $flag=0;
	      }
	  else if(trim($_POST['repassword']!=$password))
	      {
		  $repassword_err="Re-enter password";
		  $flag=0;
	      }
	  else
	      {
		  $repassword=trim($_POST['repassword']);
		  $flag=1; 
	      }
	  
	 //code to upload file.
	  $target_dir = "uploads/";
	  $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
	  $uploadOk = 1;
	  $FileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	  $location_file=$_FILES['fileToUpload']['tmp_name'];
	  $flag_upload=0;
	  $f1=0;
	  if($FileType != "jpg" && $FileType != "png" && $FileType != "jpeg")
	    {
	    
		$type_err= "Only .jpg,.png,.jpeg files are allowed.";
		$f1=1;
	    }
		
	  if($FileType == "")
	  {
		$type_err= "Upload your profile photo.";
		$f1=1;
	  }
	 if($f1 != 1)
	 {
	 if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file))
	      {
		  $uploaded_file = "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
		  $flag_upload=1;
	      } 
	  else 
	      {
		  $uploaded_file_err = "Sorry, there was an error uploading your image.";
		 
	      }
	   } 
     
       $sql = "INSERT INTO registration (`first_name`,`last_name`,`designation`,`email`,`mobile_number`,`password`) VALUES ('".$first_name."','".$last_name."','".$designation."','".$email."','".$mobile_number."','".$password."')";
    	
    	
		$mysqli->query($sql);

		$mysqli->close();
     }
     ?>